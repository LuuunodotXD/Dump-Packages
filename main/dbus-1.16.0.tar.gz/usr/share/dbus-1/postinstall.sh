#!/bin/sh
# Creates the messagebus user/group and the machine id that dbus needs.
grep -q '^messagebus:' /etc/group  || echo 'messagebus:x:81:' >> /etc/group
grep -q '^messagebus:' /etc/passwd || echo 'messagebus:x:81:81:D-Bus:/run/dbus:/bin/false' >> /etc/passwd
[ -f /etc/shadow ] && { grep -q '^messagebus:' /etc/shadow || echo 'messagebus:!:19000:0:99999:7:::' >> /etc/shadow; }
mkdir -p /var/lib/dbus /run/dbus
[ -s /etc/machine-id ] || dbus-uuidgen --ensure=/etc/machine-id
ln -sf /etc/machine-id /var/lib/dbus/machine-id
echo "dbus: messagebus user and machine id are ready."
